import type {NextApiRequest, NextApiResponse} from 'next';
import {z} from 'zod';
const Body=z.object({question:z.string().trim().min(1).max(5000)});
type Reply={answers?:Array<{provider:string;answer:string}>;error?:string};
async function call(url:string,key:string,body:unknown,headers:Record<string,string>) {const r=await fetch(url,{method:'POST',headers,body:JSON.stringify(body)}); if(!r.ok)return null;return r.json();}
async function handler(req:NextApiRequest,res:NextApiResponse<Reply>){if(req.method!=='POST')return res.status(405).json({error:'Method not allowed'});const p=Body.safeParse(req.body);if(!p.success)return res.status(400).json({error:'ورودی نامعتبر است.'});const q=p.data.question;const out:Array<{provider:string;answer:string}>=[];
try{const key=process.env.OPENAI_API_KEY;if(key){const d=await call('https://api.openai.com/v1/responses',key,{model:process.env.OPENAI_MODEL||'gpt-5.6-luna',input:q},{'content-type':'application/json','authorization':`Bearer ${key}`});if(d?.output_text)out.push({provider:'OpenAI',answer:d.output_text});}}catch{}
try{const key=process.env.GOOGLE_GENERATIVE_AI_API_KEY;if(key){const model=process.env.GEMINI_MODEL||'gemini-3.8-flash';const url=`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(key)}`;const d=await call(url,key,{contents:[{role:'user',parts:[{text:q}]}]},{'content-type':'application/json'});const answer=d?.candidates?.[0]?.content?.parts?.map((x:{text?:string})=>x.text||'').join('').trim();if(answer)out.push({provider:'Gemini',answer});}}catch{}
if(!out.length)return res.status(503).json({error:'No configured AI providers available'});return res.status(200).json({answers:out});}
export default handler;
